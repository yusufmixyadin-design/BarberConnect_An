package com.barberconnect;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.util.*;

public class MainActivity extends Activity {
    int gold = Color.rgb(232,180,45), bg = Color.rgb(12,12,14), panel = Color.rgb(28,28,32);
    boolean somali = false;
    LinearLayout page;
    String[] names = {"King Barber", "Ahmed Style", "Pro Cut"};
    String[] cities = {"Djibouti City", "Paris", "Mogadishu"};
    String[] prices = {"$15", "$12", "$20"};

    public void onCreate(Bundle b) { super.onCreate(b); home(); }
    GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold) t.setTypeface(null, Typeface.BOLD); t.setPadding(4,8,4,8); return t;
    }
    LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(1); return l; }
    LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    void base(String title) {
        page = column(); page.setPadding(20,22,20,24); page.setBackgroundColor(bg);
        ScrollView sc = new ScrollView(this); sc.setFillViewport(true); sc.addView(page); setContentView(sc);
        TextView brand = text("✂  BARBERCONNECT",22,gold,true); page.addView(brand);
        page.addView(text(title,27,Color.WHITE,true));
    }
    Button button(String label, Runnable r) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.BLACK); b.setAllCaps(false);
        b.setBackground(shape(gold,22)); b.setOnClickListener(v -> r.run()); return b;
    }
    void home() {
        base(somali ? "Timo-jareyaasha kuu dhow" : "Find your barber");
        page.addView(text(somali ? "Ballanso. Qurux yeelo." : "Book. Style. Pay.",16,gold,false));
        page.addView(text(somali ? "Raadi timo-jareyaal magaaladaada" : "Discover trusted barbers worldwide",14,Color.LTGRAY,false));
        EditText search = new EditText(this); search.setSingleLine(); search.setHint("Search city or barber…");
        search.setTextColor(Color.WHITE); search.setHintTextColor(Color.GRAY); search.setBackground(shape(panel,18)); page.addView(search);
        page.addView(button(somali ? "English" : "Somali", () -> {somali=!somali; home();}));
        for(int i=0;i<names.length;i++){
            final int n=i; LinearLayout card=column(); card.setPadding(14,12,14,12); card.setBackground(shape(panel,18));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,12,0,0); page.addView(card,cp);
            card.addView(text("💈  "+names[i],20,gold,true));
            card.addView(text("⭐ 4.8   •   "+cities[i],14,Color.WHITE,false));
            card.addView(text("Haircut "+prices[i]+"   •   Beard trim available",14,Color.LTGRAY,false));
            card.addView(button(somali ? "Eeg & ballanso" : "View & book", () -> profile(n)));
        }
        page.addView(text("OWNER • Dashboard",18,gold,true));
        page.addView(button("View demo earnings", () -> dashboard()));
    }
    void profile(int i) {
        base(names[i]);
        page.addView(text("⭐ 4.8  •  "+cities[i],16,gold,true));
        page.addView(text("Services",20,Color.WHITE,true));
        page.addView(text("Haircut — "+prices[i]+"\nBeard trim — $8\nHair + Beard — $22",16,Color.LTGRAY,false));
        page.addView(button("Book appointment", () -> booking(i)));
        page.addView(button("← Back to barbers", () -> home()));
    }
    void booking(int i) {
        base("Book appointment");
        EditText date=new EditText(this); date.setHint("Date (YYYY-MM-DD)"); date.setTextColor(Color.WHITE); page.addView(date);
        EditText time=new EditText(this); time.setHint("Time (e.g. 10:00 AM)"); time.setTextColor(Color.WHITE); page.addView(time);
        Spinner service=new Spinner(this); service.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Haircut","Beard trim","Hair + Beard"})); page.addView(service);
        page.addView(button("Confirm demo booking", () -> new AlertDialog.Builder(this).setTitle("Booking preview")
            .setMessage("Your appointment request is shown in this prototype. No server booking was created.")
            .setPositiveButton("OK",(d,w)->home()).show()));
        page.addView(button("Cancel",()->profile(i)));
    }
    void dashboard() {
        base("Owner Dashboard");
        page.addView(text("Estimated commission (demo)",16,Color.LTGRAY,false));
        page.addView(text("$125.00",38,gold,true));
        page.addView(text("Example: 10 bookings × $12.50 commission",15,Color.WHITE,false));
        page.addView(text("Revenue is illustrative only; no payments are processed.",13,Color.GRAY,false));
        page.addView(button("Back",()->home()));
    }
}
